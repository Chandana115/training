package com.student.service;

public class Student {

}
