package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExambackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExambackendApplication.class, args);
	}

}
