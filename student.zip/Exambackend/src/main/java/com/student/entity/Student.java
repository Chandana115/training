package com.student.entity;

public class Student {

		
		public int getRollno() {
			return rollno;
		}
		public void setRollno(int rollno) {
			this.rollno = rollno;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
		public String getPhno() {
			return phno;
		}
		public void setPhno(String phno) {
			this.phno = phno;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
		@Override
		public String toString() {
			return "StudentEntity [rollno=" + rollno + ", name=" + name + ", branch=" + branch + ", phno=" + phno
					+ ", email=" + email + "]";
		}

		public Student(int rollno, String name, String branch, String phno, String email) {
			super();
			this.rollno = rollno;
			this.name = name;
			this.branch = branch;
			this.phno = phno;
			this.email = email;
		}
		public Student() {
			super();
			// TODO Auto-generated constructor stub
		}

		private int rollno;

		private String name;
		private String branch;
		private String phno;
		private String email;
		
	}


